import React from 'react'

const CourseDetails = () => {
  return (
    <div>CourseDetails</div>
  )
}

export default CourseDetails