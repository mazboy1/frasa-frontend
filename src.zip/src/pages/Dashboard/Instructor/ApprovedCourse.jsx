import React from 'react'

const ApprovedCourse = () => {
  return (
    <div>ApprovedCourse</div>
  )
}

export default ApprovedCourse