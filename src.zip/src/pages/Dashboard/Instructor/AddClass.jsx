
{

//     import React, { useState } from 'react';
//     import useAxiosSecure from '../../../hooks/useAxiosSecure';
//     import  useUser  from '../../../hooks/useUser';
    
//     const KEY = import.meta.env.VITE_IMG_TOKEN;
//     const AddClass = () => {
//         const API_URL = `https://api.imgbb.com/1/upload?key=${KEY}&name=`;
//       const axiosSecure = useAxiosSecure();
//       const { currentUser, isLoading } = useUser();
//       const [image, setImage] = useState(null);
      
//       const handleFormSubmit = (e) => {
//         e.preventDefault();
//         const formData = new FormData(e.target);
//         // console.log(formData);
//         const newData = Object.fromEntries(formData);
//         formData.append('file',image)
//         console.log(newData);
//       }
//       fetch(API_URL, {
//         method: "POST",
//         body: formData,
//         })
//         .then((res) => res.json())
//         .then((data) => {
//             console.log(data);
//             if (data.success === true) {
//             console.log(data.data.display_url);
//             newData.image = data.data.display_url;
//             newData.instructorName = currentUser?.name;
//             newData.instructorEmail = currentUser?.email;
//             newData.status = 'pending';
//             newData.submitted = new Date();
//             newData.totalEnrolled = 0;
//             axiosSecure.post('/new-class', newData).then(res => {
//                 alert("Successfully added class!");
//                 console.log(res.data);
//             });
//          }
//       });
    
//       const handleImageChange = (e) => {
//         const file = e.target.files[0];
//         setImage(file);
//       }
    
    
    
//         return (
//         <div>
//             <div className="my-10">
//             <h1 className="text-center text-3xl font-bold">Add Your Course</h1>
//             </div>
//             <form onSubmit={handleFormSubmit} className="mx-auto p-6 bg-white rounded shadow">
//                 <div className="grid grid-cols-2 w-full gap-3 items-center">
//                     <div className="mb-6">
//                     <label
//                         className="block text-gray-700 font-bold mb-2"
//                         htmlFor="name"
//                     >
//                         Course Name
//                     </label>
//                     <input
//                         type="text"
//                         required
//                         placeholder="Your Course Name"
//                         name="name"
//                         id="name"
//                         className="w-full px-4 py-2 border border-secondary rounded-md focus:outline-none focus:ring-blue-500"
//                     />
//                     </div>
//                     <div className="mb-6">
//                     <label
//                         className="block text-gray-700 font-bold mb-2"
//                         htmlFor="image"
//                     >
//                         Course Thumbnail
//                     </label>
//                     <input
//                         type="file"
//                         required
//                         name="image"
//                         onChange={handleImageChange}
//                         className="block mt-[5px] w-full border border-secondary shadow-sm rounded-md text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 file:border file:bg-secondary file:text-white file:mr-4 file:py-3 file:px-4"
//                     />
//                     </div>
//                 </div>
    
//                 <div>
//                     <h1 className="text-[12px] my-2 ml-2 text-secondary">
//                         You can not change your name or email
//                     </h1>
//                     <div className="grid gap-3 grid-cols-2">
//                         <div className="mb-6">
//                             <label
//                                 className="block text-gray-700 font-bold mb-2"
//                                 htmlFor="instructorName"
//                             >
//                                 Instructor name
//                             </label>
//                             <input
//                                 className="w-full px-4 py-2 border border-secondary rounded-md focus:outline-none focus:ring-blue-500"
//                                 type="text"
//                                 defaultValue={currentUser?.name}ß                            
//                                 placeholder="Instructor Name"
//                                 name="instructorName"
//                             />
//                         </div>
//                         <div className="mb-6">
//                             <label
//                                 className="block text-gray-700 font-bold mb-2"
//                                 htmlFor="instructorName"
//                             >
//                                 Instructor name
//                             </label>
//                             <input
//                                 className="w-full px-4 py-2 border border-secondary rounded-md focus:outline-none focus:ring-blue-500"
//                                 type="text"
//                                 value={currentUser?.name}
//                                 readOnly
//                                 disabled
//                                 placeholder="Instructor Name"
//                                 name="instructorName"
//                             />
//                         </div>
//                     </div>
                
//                 </div>
    
//                 <div className="grid grid-cols-2 w-full gap-3 items-center">
//                     <div className="mb-6">
//                         <label
//                         className="block text-gray-700 font-bold mb-2"
//                         htmlFor="availableSeats"
//                         >
//                         Available seats
//                         </label>
//                         <input
//                         className="w-full border-secondary px-4 py-2 border rounded-md focus:outline-none focus: ring-blue-500"
//                         type="number"
//                         required
//                         placeholder="How many seats are available?"
//                         name="availableSeats"
//                         />
//                     </div>
    
//                     <div className="mb-6">
//                         <label className="block text-gray-700 font-bold mb-2" htmlFor="price">
//                             Price
//                         </label>
//                         <input
//                             className="w-full border-secondary px-4 py-2 border rounded-md focus:outline-none focus:ring-blue-500"
//                             type="number"
//                             required
//                             placeholder="How much does it cost?"
//                             name="price"
//                         />
//                     </div>
//                 </div>
    
//                 <div className="mb-6">
//                     <label className="block text-gray-700 font-bold mb-2" htmlFor="price">
//                         Youtube Link
//                     </label>
//                     <p className="text-[12px] my-2 mt-2 text-secondary">Only youtube videos are support</p>
//                     <input
//                         required
//                         className="w-full border-secondary px-4 py-2 border rounded-md focus:outline-none focus:ring-blue-500"
//                         type="text"
//                         placeholder="Your course intro video link"
//                         name="videoLink"
//                     />
//                 </div>
    
//                 <div className="mb-6">
//                     <label className="block text-gray-700 font-bold mb-2" htmlFor="price">
//                         Description About your course
//                     </label>
//                     <textarea
//                         placeholder="Description about your course"
//                         name="description"
//                         className="resize-none border w-full p-2 rounded-lg border-secondary outline-none"
//                         rows="4"
//                     ></textarea>
//                 </div>
    
//                 <div className="text-center w-full">
//                     <button
//                         className="bg-secondary w-full hover:bg-red-400 duration-200 text-white font-bold py-2 px-4 rounded"
//                         type="submit"
//                     >
//                         Add New Course
//                     </button>
//                 </div>
//             </form>
//         </div>
//         )
    
//     }
//     export default AddClass
}

import React, { useState } from 'react';
import useAxiosSecure from '../../../hooks/useAxiosSecure';
import useUser from '../../../hooks/useUser';

const AddClass = () => {
    const KEY = import.meta.env.VITE_IMG_TOKEN;
    const API_URL = `https://api.imgbb.com/1/upload?key=${KEY}&name=`;
    const axiosSecure = useAxiosSecure();
    const { currentUser } = useUser();
    const [image, setImage] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
  
    const handleFormSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        
        try {
            // 1. Prepare form data
            const formData = new FormData(e.target);
            if (image) {
                formData.append('image', image);
            }

            // 2. Upload image to imgBB
            let imageUrl = '';
            if (image) {
                const uploadFormData = new FormData();
                uploadFormData.append('image', image);
                
                const imgResponse = await fetch(API_URL, {
                    method: "POST",
                    body: uploadFormData,
                });
                const imgData = await imgResponse.json();
                
                if (imgData.success) {
                    imageUrl = imgData.data.display_url;
                }
            }

            // 3. Prepare class data
            const classData = {
                name: formData.get('name'),
                image: imageUrl,
                instructorName: currentUser?.name,
                instructorEmail: currentUser?.email,
                availableSeats: parseInt(formData.get('availableSeats')),
                price: parseFloat(formData.get('price')),
                videoLink: formData.get('videoLink'),
                description: formData.get('description'),
                status: 'pending',
                submitted: new Date(),
                totalEnrolled: 0
            };

            // 4. Submit to backend
            axiosSecure.post("/new-class", classData)
            
            if (response.data.success) {
                alert("Class added successfully!");
                // Reset form or redirect if needed
            }
        } catch (error) {
            console.error("Error adding class:", error);
            alert("Failed to add class. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setImage(file);
    };

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="my-10">
                <h1 className="text-center text-3xl font-bold">Add Your Course</h1>
            </div>
            
            <form onSubmit={handleFormSubmit} className="mx-auto p-6 bg-white rounded-lg shadow-md">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Course Name */}
                    <div className="mb-6">
                        <label className="block text-gray-700 font-bold mb-2" htmlFor="name">
                            Course Name
                        </label>
                        <input
                            type="text"
                            required
                            placeholder="Your Course Name"
                            name="name"
                            id="name"
                            className="w-full px-4 py-2 border border-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    {/* Course Thumbnail */}
                    <div className="mb-6">
                        <label className="block text-gray-700 font-bold mb-2" htmlFor="image">
                            Course Thumbnail
                        </label>
                        <input
                            type="file"
                            required
                            name="image"
                            onChange={handleImageChange}
                            accept="image/*"
                            className="block w-full border border-secondary shadow-sm rounded-md text-sm focus:z-10 focus:border-blue-500 focus:ring-2 focus:ring-blue-500 file:border-0 file:bg-secondary file:text-white file:mr-4 file:py-2 file:px-4"
                        />
                    </div>

                    {/* Instructor Info */}
                    <div className="mb-6">
                        <label className="block text-gray-700 font-bold mb-2">
                            Instructor Name
                        </label>
                        <input
                            className="w-full px-4 py-2 border border-secondary rounded-md bg-gray-100 cursor-not-allowed"
                            type="text"
                            value={currentUser?.name || ''}
                            readOnly
                            disabled
                        />
                    </div>

                    <div className="mb-6">
                        <label className="block text-gray-700 font-bold mb-2">
                            Instructor Email
                        </label>
                        <input
                            className="w-full px-4 py-2 border border-secondary rounded-md bg-gray-100 cursor-not-allowed"
                            type="text"
                            value={currentUser?.email || ''}
                            readOnly
                            disabled
                        />
                    </div>

                    {/* Available Seats */}
                    <div className="mb-6">
                        <label className="block text-gray-700 font-bold mb-2" htmlFor="availableSeats">
                            Available Seats
                        </label>
                        <input
                            className="w-full px-4 py-2 border border-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            type="number"
                            required
                            min="1"
                            placeholder="Number of available seats"
                            name="availableSeats"
                        />
                    </div>

                    {/* Price */}
                    <div className="mb-6">
                        <label className="block text-gray-700 font-bold mb-2" htmlFor="price">
                            Price ($)
                        </label>
                        <input
                            className="w-full px-4 py-2 border border-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                            type="number"
                            required
                            min="0"
                            step="0.01"
                            placeholder="Course price"
                            name="price"
                        />
                    </div>
                </div>

                {/* Video Link */}
                <div className="mb-6">
                    <label className="block text-gray-700 font-bold mb-2" htmlFor="videoLink">
                        YouTube Video Link
                    </label>
                    <p className="text-sm text-gray-500 mb-2">Only YouTube videos are supported</p>
                    <input
                        required
                        className="w-full px-4 py-2 border border-secondary rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        type="url"
                        placeholder="https://youtube.com/your-video"
                        name="videoLink"
                    />
                </div>

                {/* Description */}
                <div className="mb-6">
                    <label className="block text-gray-700 font-bold mb-2" htmlFor="description">
                        Course Description
                    </label>
                    <textarea
                        placeholder="Detailed description about your course"
                        name="description"
                        className="w-full p-3 border border-secondary rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        rows="5"
                        required
                    ></textarea>
                </div>

                {/* Submit Button */}
                <div className="text-center">
                    <button
                        className={`bg-secondary hover:bg-red-600 text-white font-bold py-3 px-6 rounded-lg transition duration-200 w-full ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
                        type="submit"
                        disabled={isSubmitting}
                    >
                        {isSubmitting ? 'Submitting...' : 'Add New Course'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default AddClass;