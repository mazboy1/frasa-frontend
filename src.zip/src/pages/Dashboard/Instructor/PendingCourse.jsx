import React from 'react'

const PendingCourse = () => {
  return (
    <div>PendingCourse</div>
  )
}

export default PendingCourse